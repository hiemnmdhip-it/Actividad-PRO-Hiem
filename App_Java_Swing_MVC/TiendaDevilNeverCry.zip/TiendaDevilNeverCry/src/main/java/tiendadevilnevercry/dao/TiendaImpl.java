/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiendadevilnevercry.dao;

import java.util.ArrayList;
import java.util.List;
import tiendadevilnevercry.modelo.Tienda;

/**
 *
 * @author fabia
 */
public class TiendaImpl implements TiendaDAO {
    
    private static List<Tienda> tiendas = new ArrayList<>();

    @Override
    public void nuevaTienda(Tienda nueva) {
         Integer maxId = tiendas.stream()
        .mapToInt(Tienda::getId)
        .max()
        .orElse(0);
        
        nueva.setId(maxId + 1);
        tiendas.add(nueva);  
    }

    @Override
    public Tienda getTienda(Integer id) {
         return tiendas.stream()
                .filter(t -> t.getId().equals(id))
                .findFirst()
                .orElse(null);
}

    @Override
    public List<Tienda> obtenerTiendas() {
        return tiendas;
    }

    @Override
    public void actualizarTienda(Tienda actualizar) {
        int pos = tiendas.indexOf(actualizar);
        if (pos != -1) {
        tiendas.set(pos, actualizar);
    }
    }

    @Override
    public void eliminarTienda(Integer id) {
      tiendas.removeIf(t -> t.getId().equals(id));
        }
       }
    



   
