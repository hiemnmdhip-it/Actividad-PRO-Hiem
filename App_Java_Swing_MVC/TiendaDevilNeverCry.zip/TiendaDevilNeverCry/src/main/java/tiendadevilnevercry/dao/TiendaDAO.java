/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package tiendadevilnevercry.dao;

import java.util.List;
import tiendadevilnevercry.modelo.Tienda;

/**
 *
 * @author fabia
 */
public interface TiendaDAO {
    void nuevaTienda(Tienda tienda);
    Tienda getTienda(Integer id);
    List<Tienda> obtenerTiendas();
    void actualizarTienda(Tienda tienda);
    void eliminarTienda(Integer id);
}  

