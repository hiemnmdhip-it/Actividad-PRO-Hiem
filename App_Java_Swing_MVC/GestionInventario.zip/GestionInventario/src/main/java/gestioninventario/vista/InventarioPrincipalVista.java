/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioninventario.vista;

import gestioninventario.servicio.InventarioServicio;
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;

import javax.swing.SwingUtilities;

/**
 *
 * @author fabia
 */
public class InventarioPrincipalVista extends JFrame{
      
    private final InventarioServicio servicio;
    private JTabbedPane pestañas;
    
    public InventarioPrincipalVista() {
        this.servicio = InventarioServicio.getInstance();
        
        setTitle("Sistema de Gestión de Inventario");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 700);
        setLocationRelativeTo(null);
        
        pestañas = new JTabbedPane();
        pestañas.addTab("Categorías", new PanelCategoria(servicio));
        pestañas.addTab("Productos", new PanelProducto(servicio));
        
        add(pestañas, BorderLayout.CENTER);
        setVisible(true);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new InventarioPrincipalVista());
    }
}
    

