/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package tiendadevilnevercry.vista;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import tiendadevilnevercry.modelo.Producto;
import tiendadevilnevercry.modelo.Tienda;
import tiendadevilnevercryservicio.TiendaServicio;
/**
 *
 * @author fabia
 */
public class ProductosVista extends javax.swing.JDialog {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ProductosVista.class.getName());

    /**
     * Creates new form ProductosVista
     */
    private TiendaServicio servicio;
    private Tienda tiendaActual;
    private List<Producto> productos;
    private int indiceActual = 0;
    private enum Estado { CONSULTA, ALTA, MODIFICACION }
    private Estado estadoActual = Estado.CONSULTA;

    
    public ProductosVista(java.awt.Frame parent, Tienda tienda) {
        super(parent, true);
        initComponents();
        this.getContentPane().setBackground(new Color(26, 26, 26));
        this.setLocationRelativeTo(null);
        inicializarTabla(); 
        this.tiendaActual = tienda;
        this.servicio = TiendaServicio.getInstancia();
        cargarProductos();
        cargarPrimerProducto();
        actualizarEstado();

        // Evento de selección de tabla
        tblProducto.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tblProducto.getSelectedRow() != -1) {
                indiceActual = tblProducto.getSelectedRow();
                mostrarProducto(productos.get(indiceActual));
            }
        });
    }

    private void cargarProductos() {
        productos = servicio.obtenerTodosLosProductos();
        // Filtrar solo los productos de esta tienda (sin Streams)
        List<Producto> productosFiltered = new ArrayList<>();
        for (Producto p : productos) {
            if (p.getIdTienda() == tiendaActual.getId()) {
                productosFiltered.add(p);
            }
        }
        productos = productosFiltered;
    }

    private void cargarPrimerProducto() {
        cargarTabla();
        if (!productos.isEmpty()) {
            tblProducto.setRowSelectionInterval(0, 0);  // ← Cambiar aquí
            mostrarProducto(productos.get(indiceActual));
        } else {
            limpiarCampos();
        }
    }

    private void mostrarProducto(Producto producto) {
        txtIdProducto.setText(String.valueOf(producto.getId()));
        txtNombreProducto.setText(producto.getNombre());
        txtPrecioProducto.setText(String.valueOf(producto.getPrecio()));
        txtStockProducto.setText(String.valueOf(producto.getStock()));
    }

    private void actualizarEstado() {
        switch (estadoActual) {
            case CONSULTA:
                txtNombreProducto.setEnabled(false);
                txtPrecioProducto.setEnabled(false);
                txtStockProducto.setEnabled(false);
                btnNuevoProducto.setEnabled(true);
                btnGuardarProducto.setEnabled(false);
                btnCancelarProducto.setEnabled(false);
                btnEliminar.setEnabled(!productos.isEmpty());
                break;
            case ALTA:
            case MODIFICACION:
                txtNombreProducto.setEnabled(true);
                txtPrecioProducto.setEnabled(true);
                txtStockProducto.setEnabled(true);
                btnNuevoProducto.setEnabled(false);
                btnGuardarProducto.setEnabled(true);
                btnCancelarProducto.setEnabled(true);
                btnEliminar.setEnabled(false);
                break;
        }
    }

    private void limpiarCampos() {
        txtIdProducto.setText("");
        txtNombreProducto.setText("");
        txtPrecioProducto.setText("");
        txtStockProducto.setText("");
    }
    private DefaultTableModel modeloTabla;

    private void inicializarTabla() {

    String[] titulos = { "ID", "Nombre", "Descripción", "Precio", "Stock" };

    modeloTabla = new DefaultTableModel(null, titulos) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false; 
        }
    };

    tblProducto.setModel(modeloTabla);
    
    tblProducto.setRowHeight(25);

    if (tblProducto.getColumnModel().getColumnCount() > 0) {
        tblProducto.getColumnModel().getColumn(0).setPreferredWidth(30);
        tblProducto.getColumnModel().getColumn(0).setMaxWidth(50);
        tblProducto.getColumnModel().getColumn(2).setPreferredWidth(250);
    }
    
    // DISEÑO/COLORES TABLA.
    jTable1.setBackground(new Color(42, 42, 42));
    jTable1.setForeground(new Color(255, 255, 255));
    jTable1.setGridColor(new Color(204, 0, 0));
    jTable1.setSelectionBackground(new Color(139, 0, 0));
    jTable1.setSelectionForeground(new Color(255, 255, 255));

    
    jTable1.getTableHeader().setBackground(new Color(26, 26, 26));
    jTable1.getTableHeader().setForeground(new Color(255, 255, 255));
    
    
    }

    private void cargarTabla() {
        modeloTabla.setRowCount(0);
        for (Producto p : productos) {
            modeloTabla.addRow(new Object[] {
                p.getId(),
                p.getNombre(),
                p.getDescripcion(),
                p.getPrecio(),
                p.getStock()
            });
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        ID = new javax.swing.JLabel();
        txtIdProducto = new javax.swing.JTextField();
        Nombre = new javax.swing.JLabel();
        txtNombreProducto = new javax.swing.JTextField();
        Precio = new javax.swing.JLabel();
        txtPrecioProducto = new javax.swing.JTextField();
        Stock = new javax.swing.JLabel();
        txtStockProducto = new javax.swing.JTextField();
        btnNuevoProducto = new javax.swing.JButton();
        btnGuardarProducto = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnCancelarProducto = new javax.swing.JButton();
        tblProductos = new java.awt.ScrollPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblProducto = new javax.swing.JTable();
        btnVolverProducto = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Productos Devil Never Cry");

        ID.setForeground(new java.awt.Color(242, 242, 242));
        ID.setText("ID");

        txtIdProducto.setBackground(new java.awt.Color(58, 58, 58));
        txtIdProducto.setForeground(new java.awt.Color(255, 255, 255));
        txtIdProducto.setCaretColor(new java.awt.Color(204, 0, 0));
        txtIdProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdProductoActionPerformed(evt);
            }
        });

        Nombre.setForeground(new java.awt.Color(242, 242, 242));
        Nombre.setText("Nombre");

        txtNombreProducto.setBackground(new java.awt.Color(58, 58, 58));
        txtNombreProducto.setForeground(new java.awt.Color(255, 255, 255));
        txtNombreProducto.setCaretColor(new java.awt.Color(204, 0, 0));
        txtNombreProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreProductoActionPerformed(evt);
            }
        });

        Precio.setForeground(new java.awt.Color(242, 242, 242));
        Precio.setText("Precio");

        txtPrecioProducto.setBackground(new java.awt.Color(58, 58, 58));
        txtPrecioProducto.setForeground(new java.awt.Color(255, 255, 255));
        txtPrecioProducto.setCaretColor(new java.awt.Color(204, 0, 0));
        txtPrecioProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecioProductoActionPerformed(evt);
            }
        });

        Stock.setForeground(new java.awt.Color(242, 242, 242));
        Stock.setText("Stock");

        txtStockProducto.setBackground(new java.awt.Color(58, 58, 58));
        txtStockProducto.setForeground(new java.awt.Color(255, 255, 255));
        txtStockProducto.setCaretColor(new java.awt.Color(204, 0, 0));
        txtStockProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtStockProductoActionPerformed(evt);
            }
        });

        btnNuevoProducto.setBackground(new java.awt.Color(139, 0, 0));
        btnNuevoProducto.setForeground(new java.awt.Color(255, 255, 255));
        btnNuevoProducto.setText("Nuevo");
        btnNuevoProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoProductoActionPerformed(evt);
            }
        });

        btnGuardarProducto.setBackground(new java.awt.Color(139, 0, 0));
        btnGuardarProducto.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardarProducto.setText("Guardar");
        btnGuardarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarProductoActionPerformed(evt);
            }
        });

        btnEliminar.setBackground(new java.awt.Color(139, 0, 0));
        btnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnCancelarProducto.setBackground(new java.awt.Color(139, 0, 0));
        btnCancelarProducto.setForeground(new java.awt.Color(255, 255, 255));
        btnCancelarProducto.setText("Cancelar");
        btnCancelarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarProductoActionPerformed(evt);
            }
        });

        tblProductos.setBackground(new java.awt.Color(42, 42, 42));
        tblProductos.setPreferredSize(new java.awt.Dimension(500, 400));

        tblProducto.setBackground(new java.awt.Color(42, 42, 42));
        tblProducto.setForeground(new java.awt.Color(255, 255, 255));
        tblProducto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Precio", "Productos Devil Never Cry", "Descripción"
            }
        ));
        tblProducto.setGridColor(new java.awt.Color(204, 0, 0));
        tblProducto.setSelectionBackground(new java.awt.Color(39, 0, 0));
        tblProducto.setSelectionForeground(new java.awt.Color(255, 255, 255));
        tblProducto.setShowGrid(true);
        jScrollPane2.setViewportView(tblProducto);

        tblProductos.add(jScrollPane2);

        btnVolverProducto.setBackground(new java.awt.Color(139, 0, 0));
        btnVolverProducto.setForeground(new java.awt.Color(255, 255, 255));
        btnVolverProducto.setText("Volver");
        btnVolverProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverProductoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ID, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Precio, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Stock, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtIdProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPrecioProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtStockProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(btnNuevoProducto)
                        .addGap(49, 49, 49)
                        .addComponent(btnGuardarProducto)
                        .addGap(44, 44, 44)
                        .addComponent(btnCancelarProducto)
                        .addGap(49, 49, 49)
                        .addComponent(btnEliminar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnVolverProducto)
                        .addGap(17, 17, 17))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(tblProductos, javax.swing.GroupLayout.DEFAULT_SIZE, 684, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(53, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ID)
                            .addComponent(txtIdProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Nombre)
                            .addComponent(txtNombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Precio)
                            .addComponent(txtPrecioProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Stock)
                            .addComponent(txtStockProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(tblProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNuevoProducto)
                    .addComponent(btnGuardarProducto)
                    .addComponent(btnEliminar)
                    .addComponent(btnCancelarProducto)
                    .addComponent(btnVolverProducto))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNombreProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreProductoActionPerformed

    private void txtPrecioProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecioProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecioProductoActionPerformed

    private void txtStockProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtStockProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtStockProductoActionPerformed

    private void btnNuevoProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoProductoActionPerformed
estadoActual = Estado.ALTA;
    limpiarCampos();
    actualizarEstado();
    }//GEN-LAST:event_btnNuevoProductoActionPerformed

    private void btnGuardarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarProductoActionPerformed
if (txtNombreProducto.getText().isEmpty() || txtPrecioProducto.getText().isEmpty() || txtStockProducto.getText().isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    try {
        double precio = Double.parseDouble(txtPrecioProducto.getText());
        int stock = Integer.parseInt(txtStockProducto.getText());
        
        if (estadoActual == Estado.ALTA) {
            Producto nuevo = new Producto();
            nuevo.setNombre(txtNombreProducto.getText());
            nuevo.setPrecio(precio);
            nuevo.setStock(stock);
            nuevo.setIdTienda(tiendaActual.getId());
            servicio.crearProducto(nuevo);
            javax.swing.JOptionPane.showMessageDialog(this, "Producto creado exitosamente", "Éxito", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        } else if (estadoActual == Estado.MODIFICACION) {
            Producto actualizar = productos.get(indiceActual);
            actualizar.setNombre(txtNombreProducto.getText());
            actualizar.setPrecio(precio);
            actualizar.setStock(stock);
            servicio.actualizarProducto(actualizar);
            javax.swing.JOptionPane.showMessageDialog(this, "Producto actualizado exitosamente", "Éxito", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        }
        
        cargarProductos();
        indiceActual = 0;
        cargarPrimerProducto();
        estadoActual = Estado.CONSULTA;
        actualizarEstado();
    } catch (NumberFormatException e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Precio y Stock deben ser números válidos", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
    }    }//GEN-LAST:event_btnGuardarProductoActionPerformed

    private void btnCancelarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarProductoActionPerformed
    estadoActual = Estado.CONSULTA;
    cargarPrimerProducto();
    actualizarEstado();    }//GEN-LAST:event_btnCancelarProductoActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
if (productos.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "No hay productos para eliminar", "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    int confirmacion = javax.swing.JOptionPane.showConfirmDialog(this,
        "¿Está seguro de que desea eliminar este producto?",
        "Confirmar eliminación",
        javax.swing.JOptionPane.YES_NO_OPTION);
    
    if (confirmacion == javax.swing.JOptionPane.YES_OPTION) {
        Producto productoActual = productos.get(indiceActual);
        servicio.eliminarProducto(productoActual.getId());
        cargarProductos();
        
        if (!productos.isEmpty()) {
            indiceActual = 0;
            mostrarProducto(productos.get(indiceActual));
        } else {
            limpiarCampos();
        }
        
        estadoActual = Estado.CONSULTA;
        actualizarEstado();
        javax.swing.JOptionPane.showMessageDialog(this, "Producto eliminado exitosamente", "Éxito", javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }    }//GEN-LAST:event_btnEliminarActionPerformed

    private void txtIdProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdProductoActionPerformed

    private void btnVolverProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverProductoActionPerformed
    this.dispose();    }//GEN-LAST:event_btnVolverProductoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
    /* Set the Nimbus look and feel */
    //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
    try {
        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            if ("Nimbus".equals(info.getName())) {
                javax.swing.UIManager.setLookAndFeel(info.getClassName());
                break;
            }
        }
    } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
        logger.log(java.util.logging.Level.SEVERE, null, ex);
    
    }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ID;
    private javax.swing.JLabel Nombre;
    private javax.swing.JLabel Precio;
    private javax.swing.JLabel Stock;
    private javax.swing.JButton btnCancelarProducto;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardarProducto;
    private javax.swing.JButton btnNuevoProducto;
    private javax.swing.JButton btnVolverProducto;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable tblProducto;
    private java.awt.ScrollPane tblProductos;
    private javax.swing.JTextField txtIdProducto;
    private javax.swing.JTextField txtNombreProducto;
    private javax.swing.JTextField txtPrecioProducto;
    private javax.swing.JTextField txtStockProducto;
    // End of variables declaration//GEN-END:variables
}
