/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiendadevilnevercry.modelo;

import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author fabia
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Tienda {
    private Integer id;
    private String nombre;
    private String ubicacion;
    private String telefono;
     private List<Producto> productos = new ArrayList<>();
     
     @Override
    public String toString() {
        return nombre;
}
}
