/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package gestioninventario.dao;

import gestioninventario.modelo.Producto;
import java.util.List;

/**
 *
 * @author fabia
 */
public interface ProductoDAO {
    Producto getProducto(Integer id);
    void modificarProducto (Producto modificar);
    void eliminarProducto (Producto eliminar);
    Producto nuevoProducto (Producto nuevo);
    List <Producto> getProducto();
}
