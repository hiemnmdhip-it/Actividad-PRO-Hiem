/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiendadevilnevercry.dao;

import java.util.ArrayList;
import java.util.List;
import tiendadevilnevercry.modelo.Producto;


/**
 *
 * @author fabia
 */
public class ProductoImpl implements ProductoDAO{

    private static List<Producto> productos = new ArrayList<>();
    
    @Override
    public void nuevoProducto(Producto nuevo) {
      Integer maxId = productos.stream()
        .mapToInt(Producto::getId)
        .max()
        .orElse(0);
        
        nuevo.setId(maxId + 1);
        productos.add(nuevo);
    }

        @Override
        public Producto getProducto(Integer id) {
           return productos.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst()
                .orElse(null);
        
}
        @Override
        public List<Producto> obtenerProductos() {
            return productos;
        }
        

        @Override
        public void actualizarProducto(Producto actualizar) {
               int pos = productos.indexOf(actualizar);
        if (pos != -1) {
        productos.set(pos, actualizar);
    }
    }

        @Override
        public void eliminarProducto(Integer id) {
           productos.removeIf(p -> p.getId().equals(id));
        }
       }
    

