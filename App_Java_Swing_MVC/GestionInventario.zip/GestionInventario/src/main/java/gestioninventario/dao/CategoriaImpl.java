/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioninventario.dao;

import gestioninventario.modelo.Categoria;
import gestioninventario.modelo.Producto;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author fabia
 */
public class CategoriaImpl implements CategoriaDAO {
    
    private static List<Categoria> categorias = new ArrayList<>();

    @Override
  public Categoria getCategoria(Integer id) {
    return categorias.stream()
        .filter(c -> c.getId() == id)  
        .findFirst()
        .orElse(null);
}
    @Override
    public Categoria nuevaCategoria(Categoria nueva) {
            Integer maxId = categorias.stream()
            .map(Categoria::getId)
            .max(Integer::compareTo)
            .orElse(0);
             nueva.setId(maxId + 1);
             categorias.add(nueva);
        return nueva;
            }
    

    @Override
    public List<Categoria> getCategoria() {
        return categorias;
    }

    @Override
    public void agregarProducto(Categoria c, Producto p) {   
        c.getProductos().add(p);
        p.setCategoria(c);
    }
    
    @Override
    public void eliminarCategoria(Categoria eliminar) {
               categorias.remove(eliminar);    
    }

    @Override
    public void actualizarCategoria(Categoria actualizar) {
       int pos = categorias.indexOf(actualizar);
        if (pos != -1) {
        categorias.set(pos, actualizar);
    }
    }
}
