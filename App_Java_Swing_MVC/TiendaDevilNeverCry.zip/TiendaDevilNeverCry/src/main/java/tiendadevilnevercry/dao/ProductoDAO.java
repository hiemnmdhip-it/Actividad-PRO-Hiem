/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package tiendadevilnevercry.dao;

import java.util.List;
import tiendadevilnevercry.modelo.Producto;


/**
 *
 * @author fabia
 */
public interface ProductoDAO {
    void nuevoProducto(Producto producto);
    Producto getProducto(Integer id);
    List<Producto> obtenerProductos();
    void actualizarProducto(Producto producto);  
    void eliminarProducto(Integer id);           
}