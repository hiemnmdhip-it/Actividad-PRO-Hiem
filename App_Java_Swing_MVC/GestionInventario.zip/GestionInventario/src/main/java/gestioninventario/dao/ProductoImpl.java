/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioninventario.dao;

import gestioninventario.modelo.Producto;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author fabia
 */
public class ProductoImpl implements ProductoDAO {

    private static List<Producto> productos = new ArrayList<>();
    
    @Override
    public Producto getProducto(Integer id) {
        Producto buscar = new Producto();
            buscar.setId(id);
            int pos = productos.indexOf(buscar); 
            if (pos != -1){
                return productos.get(pos);
            } else {
                return null;    
            }
    }    

    @Override
    public void modificarProducto(Producto modificar) {
        int pos = productos.indexOf(modificar);
        if ( pos != -1){
            productos.set(pos, modificar);
        }
    }    

    @Override
    public void eliminarProducto(Producto eliminar) {
        eliminar.getCategoria().getProductos().remove(eliminar);
        productos.remove(eliminar);
        }

    @Override
    public Producto nuevoProducto(Producto nuevo) {
            Integer maxId = productos.stream()
            .map(Producto::getId)
            .max(Integer::compareTo)
            .orElse(0);
        nuevo.setId(maxId + 1);
        productos.add(nuevo);
        nuevo.getCategoria().getProductos().add(nuevo);
        return nuevo;
    }

    @Override
    public List<Producto> getProducto() {
        return productos;
    }
   
   
    
}
