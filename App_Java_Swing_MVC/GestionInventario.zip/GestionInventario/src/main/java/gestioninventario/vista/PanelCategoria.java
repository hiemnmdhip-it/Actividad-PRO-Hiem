/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioninventario.vista;
import gestioninventario.modelo.Categoria;
import gestioninventario.servicio.InventarioServicio;
import gestioninventario.util.Estado;
import static gestioninventario.util.Estado.ALTA;
import static gestioninventario.util.Estado.CONSULTA;
import static gestioninventario.util.Estado.MODIFICACION;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;


/**
 *
 * @author fabia
 */
public class PanelCategoria extends JPanel {

    private InventarioServicio servicio;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private JTextField txtNombre, txtDescripcion;
    private JButton btnNuevo, btnEditar, btnEliminar, btnGuardar, btnCancelar;
    private Estado estado;
    private Categoria categoriaSeleccionada;

    public PanelCategoria(InventarioServicio servicio) {
        this.servicio = servicio;
        this.estado = Estado.CONSULTA;

        setLayout(new BorderLayout());

        // Panel superior: Tabla
        JPanel panelTabla = crearPanelTabla();
        add(panelTabla, BorderLayout.CENTER);

        // Panel inferior: Formulario
        JPanel panelFormulario = crearPanelFormulario();
        add(panelFormulario, BorderLayout.SOUTH);

        cargarDatos();
    }

    private JPanel crearPanelTabla() {
        JPanel panel = new JPanel(new BorderLayout());

        // Crear tabla
        modeloTabla = new DefaultTableModel(
            new String[]{"ID", "Nombre", "Descripción"}, 0
        );
        tabla = new JTable(modeloTabla);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // seleccionar fila
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() != -1) {
                int id = (int) modeloTabla.getValueAt(tabla.getSelectedRow(), 0);
                categoriaSeleccionada = servicio.getCategoriaDAO().getCategoria(id);
            }
        });

        JScrollPane scroll = new JScrollPane(tabla);
        panel.add(scroll, BorderLayout.CENTER);

        // Panel de botones
        JPanel panelBotones = new JPanel();
        btnNuevo = new JButton("Nuevo");
        btnEditar = new JButton("Editar");
        btnEliminar = new JButton("Eliminar");

        btnNuevo.addActionListener(e -> cambiarEstado(Estado.ALTA));
        btnEditar.addActionListener(e -> cambiarEstado(Estado.MODIFICACION));
        btnEliminar.addActionListener(e -> eliminarCategoria());

        panelBotones.add(btnNuevo);
        panelBotones.add(btnEditar);
        panelBotones.add(btnEliminar);

        panel.add(panelBotones, BorderLayout.NORTH);

        return panel;
    }

    private JPanel crearPanelFormulario() {
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(BorderFactory.createTitledBorder("Formulario"));

        panel.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panel.add(txtNombre);

        panel.add(new JLabel("Descripción:"));
        txtDescripcion = new JTextField();
        panel.add(txtDescripcion);

        JPanel panelBotones = new JPanel();
        btnGuardar = new JButton("Guardar");
        btnCancelar = new JButton("Cancelar");

        btnGuardar.addActionListener(e -> guardarCategoria());
        btnCancelar.addActionListener(e -> cambiarEstado(Estado.CONSULTA));

        panelBotones.add(btnGuardar);
        panelBotones.add(btnCancelar);
        panel.add(panelBotones);

        return panel;
    }

    private void cambiarEstado(Estado nuevoEstado) {
        this.estado = nuevoEstado;

        switch (estado) {
            case CONSULTA:
                limpiarFormulario();
                habilitarFormulario(false);
                break;
            case ALTA:
                limpiarFormulario();
                habilitarFormulario(true);
                break;
            case MODIFICACION:
                if (categoriaSeleccionada != null) {
                    txtNombre.setText(categoriaSeleccionada.getNombre());
                    txtDescripcion.setText(categoriaSeleccionada.getDescripcion());
                    habilitarFormulario(true);
                }
                break;
        }
    }

    private void habilitarFormulario(boolean habilitar) {
        txtNombre.setEnabled(habilitar);
        txtDescripcion.setEnabled(habilitar);
        btnGuardar.setEnabled(habilitar);
        btnNuevo.setEnabled(!habilitar);
        btnEditar.setEnabled(!habilitar);
        btnEliminar.setEnabled(!habilitar);
    }

    private void limpiarFormulario() {
        txtNombre.setText("");
        txtDescripcion.setText("");
    }

    private void guardarCategoria() {
        String nombre = txtNombre.getText().trim();
        String descripcion = txtDescripcion.getText().trim();

        if (nombre.isEmpty() || descripcion.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Completa todos los campos");
            return;
        }

        if (estado == Estado.ALTA) {
            Categoria nueva = new Categoria();
            nueva.setNombre(nombre);
            nueva.setDescripcion(descripcion);
            servicio.getCategoriaDAO().nuevaCategoria(nueva);
        } else if (estado == Estado.MODIFICACION) {
            categoriaSeleccionada.setNombre(nombre);
            categoriaSeleccionada.setDescripcion(descripcion);
            servicio.getCategoriaDAO().actualizarCategoria(categoriaSeleccionada);
        }

        cargarDatos();
        cambiarEstado(Estado.CONSULTA);
    }

    private void eliminarCategoria() {
        if (categoriaSeleccionada == null) {
            JOptionPane.showMessageDialog(this, "Selecciona una categoría");
            return;
        }

        int opcion = JOptionPane.showConfirmDialog(this, "¿Eliminar esta categoría?");
        if (opcion == JOptionPane.YES_OPTION) {
            servicio.getCategoriaDAO().eliminarCategoria(categoriaSeleccionada);
            cargarDatos();
            cambiarEstado(Estado.CONSULTA);
        }
    }

    private void cargarDatos() {
        modeloTabla.setRowCount(0);
        List<Categoria> categorias = servicio.getCategoriaDAO().getCategoria();
        for (Categoria c : categorias) {
            modeloTabla.addRow(new Object[]{
                c.getId(), c.getNombre(), c.getDescripcion()
            });
        }
    }
}

