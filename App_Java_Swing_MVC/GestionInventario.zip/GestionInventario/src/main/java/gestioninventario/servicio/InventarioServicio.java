/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioninventario.servicio;

import gestioninventario.dao.CategoriaDAO;
import gestioninventario.dao.CategoriaImpl;
import gestioninventario.dao.ProductoDAO;
import gestioninventario.dao.ProductoImpl;
import gestioninventario.modelo.Categoria;
import gestioninventario.modelo.Producto;
import java.util.List;

/**
 *
 * @author fabia
 */
public class InventarioServicio {
    private static InventarioServicio instancia;
    private CategoriaDAO categoriaDAO;
    private ProductoDAO productoDAO;
    
    private InventarioServicio() {
      
        this.categoriaDAO = new CategoriaImpl();
        this.productoDAO = new ProductoImpl();
        cargarDatos();
    }
    
    public static InventarioServicio getInstance() {
        if (instancia == null) {
            instancia = new InventarioServicio();
        }
        return instancia;
        
    }

        private void cargarDatos() {
         Categoria electronica = new Categoria();
        electronica.setId(0);
        electronica.setNombre("Electrónica");
        electronica.setDescripcion("Gadgets y hardware");
    
        Categoria hogar = new Categoria();
        hogar.setId(0);
        hogar.setNombre("Hogar");
        hogar.setDescripcion("Artículos para el hogar");
    
        Categoria oficina = new Categoria();
        oficina.setId(0);
        oficina.setNombre("Oficina");
        oficina.setDescripcion("Artículos para la oficina");
        
        categoriaDAO.nuevaCategoria(electronica);
        categoriaDAO.nuevaCategoria(hogar);
        categoriaDAO.nuevaCategoria(oficina);
        
        //Electrónica
        productoDAO.nuevoProducto(new Producto(0, "Laptop Gamer", 1200.50, 10, electronica));
        productoDAO.nuevoProducto(new Producto(0, "Mouse Pro", 45.00, 25, electronica));
        
        //Hogar
        productoDAO.nuevoProducto(new Producto(0, "Cafetera Express", 89.90, 15, hogar));
        productoDAO.nuevoProducto(new Producto(0, "Lámpara LED", 25.00, 40, hogar));
        
        // Oficina
        productoDAO.nuevoProducto(new Producto(0, "Silla Ergonómica", 150.00, 5, oficina));
        productoDAO.nuevoProducto(new Producto(0, "Escritorio Madera", 210.00, 8, oficina));
    }
    public CategoriaDAO getCategoriaDAO() {
        return categoriaDAO;    
}

    public Categoria nuevaCategoria(Categoria nueva) {
        return categoriaDAO.nuevaCategoria(nueva);
    }

    public List<Categoria> getCategoria() {
        return categoriaDAO.getCategoria();
    }

    public void agregarProducto(Categoria c, Producto p) {
        categoriaDAO.agregarProducto(c, p);
    }

    public void eliminarCategoria(Categoria eliminar) {
        categoriaDAO.eliminarCategoria(eliminar);
    }

    public void actualizarCategoria(Categoria actualizar) {
        categoriaDAO.actualizarCategoria(actualizar);
    }


    public ProductoDAO getProductoDAO() {
    return productoDAO;  
    }
    
    public void modificarProducto(Producto modificar) {
        productoDAO.modificarProducto(modificar);
    }

    public void eliminarProducto(Producto eliminar) {
        productoDAO.eliminarProducto(eliminar);
    }

    public Producto nuevoProducto(Producto nuevo) {
        return productoDAO.nuevoProducto(nuevo);
    }

    public List<Producto> getProducto() {
        return productoDAO.getProducto();
    }

}