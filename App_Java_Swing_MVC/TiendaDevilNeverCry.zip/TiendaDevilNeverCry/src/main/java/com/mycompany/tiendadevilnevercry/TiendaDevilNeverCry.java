/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tiendadevilnevercry;

import tiendadevilnevercry.vista.DevilNeverCryPrincipalVista;

/**
 *
 * @author fabia
 */
public class TiendaDevilNeverCry {

    public static void main(String[] args) {
          new DevilNeverCryPrincipalVista().setVisible(true);
    }
}
    

