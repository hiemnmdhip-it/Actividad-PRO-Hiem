/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiendadevilnevercryservicio;

import java.util.List;
import tiendadevilnevercry.dao.ProductoDAO;
import tiendadevilnevercry.dao.ProductoImpl;
import tiendadevilnevercry.dao.TiendaDAO;
import tiendadevilnevercry.dao.TiendaImpl;
import tiendadevilnevercry.modelo.Producto;
import tiendadevilnevercry.modelo.Tienda;

/**
 *
 * @author fabia
 */
public class TiendaServicio {
    private static TiendaServicio instancia;
    private TiendaDAO tiendaDAO;
    private ProductoDAO productoDAO;
    
    private TiendaServicio() {
        
        this.tiendaDAO = new TiendaImpl();
        this.productoDAO = new ProductoImpl();
        cargarDatos();
    }

    public static TiendaServicio getInstancia(){
         if (instancia == null) {
            instancia = new TiendaServicio();
        }
        return instancia;
        
    }
    
  private void cargarDatos() {

        // ========================================================
        // TIENDA 1: CONSUMIBLES
        // ========================================================
        Tienda tienda1 = new Tienda();
        tienda1.setNombre("Estatua de la Divinidad (Items)");
        tienda1.setUbicacion("Mallet Island - Hall");
        tienda1.setTelefono("N/A - Time");
        tiendaDAO.nuevaTienda(tienda1); 
        
        // ID Tienda 1
        agregarProducto("Vital Star (S)", "Restaura una pequeña cantidad de vitalidad.", 500.0, 50, 1);
        agregarProducto("Devil Star", "Restaura la barra de Devil Trigger", 600.0, 30, 1);
        agregarProducto("Holy Water", "Agua bendita que daña gravemente a los enemigos.", 700.0, 10, 1);
        agregarProducto("Blue Orb", "Fragmento de vida.", 300.0, 12, 1);
        agregarProducto("Yellow Orb", "Piedra mágica que permite resucitar.", 1000.0, 3, 1);

        // ========================================================
        // TIENDA 2: DANTE (Armas y Skills)
        // ========================================================
        Tienda tienda2 = new Tienda();
        tienda2.setNombre("Devil May Cry (Oficina)");
        tienda2.setUbicacion("Redgrave City");
        tienda2.setTelefono("555-338-45");
        tiendaDAO.nuevaTienda(tienda2); 
        
        // Armas
        agregarProducto("Rebellion", "Espada recuerdo dejada por el padre de Dante.", 50000.0, 1, 2);
        agregarProducto("Ebony & Ivory", "Pistolas hechas a mano. 'Para Tony Redgrave'.", 45000.0, 1, 2);
        agregarProducto("Alastor", "El espíritu del Rayo. Otorga velocidad eléctrica.", 60000.0, 1, 2);
        agregarProducto("Ifrit", "El espíritu del Fuego. Poder destructivo cuerpo a cuerpo.", 60000.0, 1, 2);

        // Skills
        agregarProducto("Skill: Stinger", "Ataque perforante a alta velocidad hacia el enemigo.", 250.0, 1, 2);
        agregarProducto("Skill: Air Hike", "Concentra magia bajo los pies para realizar un doble salto.", 4000.0, 1, 2);
        agregarProducto("Skill: Air Raid", "Permite volar y disparar rayos (Requiere Alastor).", 750.0, 1, 2);
        agregarProducto("Skill: Inferno", "Golpea el suelo y quema todo con llamas del infierno.", 2850.0, 1, 2);

        // ========================================================
        // TIENDA 3: VERGIL (Poder)
        // ========================================================
        Tienda tienda3 = new Tienda();
        tienda3.setNombre("Vergil's Arsenal");
        tienda3.setUbicacion("Torre Temen-Ni-Gru");
        tienda3.setTelefono("666-769-37"); 
        tiendaDAO.nuevaTienda(tienda3); 
        
        // Vergil Items
        agregarProducto("Yamato", "La katana que separa al hombre del demonio.", 150000.0, 1, 3);
        agregarProducto("Mirage Edge", "Espada invocada con la propia alma de Vergil.", 60000.0, 1, 3);
        agregarProducto("Judgment Cut", "Corte dimensional tan rápido que no se ve.", 5000.0, 1, 3);
        agregarProducto("Judgment Cut End", "Corta el espacio-tiempo.", 500000.0, 1, 3);
    }

    private void agregarProducto(String nombre, String desc, double precio, int stock, int idTienda) {
        Producto p = new Producto();
        p.setNombre(nombre);
        p.setDescripcion(desc); 
        p.setPrecio(precio);
        p.setStock(stock);
        p.setIdTienda(idTienda);
        productoDAO.nuevoProducto(p);
    }
    
    public void crearTienda(Tienda tienda) {
        tiendaDAO.nuevaTienda(tienda);
    }

    public Tienda obtenerTienda(Integer id) {
        return tiendaDAO.getTienda(id);
    }

    public List<Tienda> obtenerTodasLasTiendas() {
        return tiendaDAO.obtenerTiendas();
    }

    public void actualizarTienda(Tienda tienda) {
        tiendaDAO.actualizarTienda(tienda);
    }

    public void eliminarTienda(Integer id) {
        tiendaDAO.eliminarTienda(id);
    }

    public void crearProducto(Producto producto) {
    productoDAO.nuevoProducto(producto);
    
    Tienda tienda = tiendaDAO.getTienda(producto.getIdTienda());
    
    if (tienda != null) {
        tienda.getProductos().add(producto);
    }
    }

    public Producto obtenerProducto(Integer id) {
        return productoDAO.getProducto(id);
    }

    public List<Producto> obtenerTodosLosProductos() {
        return productoDAO.obtenerProductos();
    }

    public void actualizarProducto(Producto producto) {
        productoDAO.actualizarProducto(producto);
    }

    public void eliminarProducto(Integer id) {
    Producto producto = productoDAO.getProducto(id);
    if (producto != null) {
        Tienda tienda = tiendaDAO.getTienda(producto.getIdTienda());
        if (tienda != null) {
            tienda.getProductos().remove(producto);
        }
    }
         productoDAO.eliminarProducto(id);
}
}
