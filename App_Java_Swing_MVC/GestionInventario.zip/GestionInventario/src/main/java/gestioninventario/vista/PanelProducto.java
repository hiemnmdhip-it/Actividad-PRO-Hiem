/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioninventario.vista;

import gestioninventario.modelo.Categoria;
import gestioninventario.modelo.Producto;
import gestioninventario.servicio.InventarioServicio;
import static gestioninventario.util.Estado.ALTA;
import static gestioninventario.util.Estado.CONSULTA;
import static gestioninventario.util.Estado.MODIFICACION;
import static java.awt.AWTEventMulticaster.add;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import gestioninventario.util.Estado;
/**
 *
 * @author fabia
 */
public class PanelProducto extends JPanel {
    private InventarioServicio servicio;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private JTextField txtNombre, txtPrecio, txtCantidad;
    private JComboBox<Categoria> cmbCategoria;
    private JButton btnNuevo, btnEditar, btnEliminar, btnGuardar, btnCancelar;
    private Estado estado;
    private Producto productoSeleccionado;
    
    public PanelProducto(InventarioServicio servicio) {
        this.servicio = servicio;
        this.estado = Estado.CONSULTA;
        
        setLayout(new BorderLayout());
        
        // Panel superior: Tabla
        JPanel panelTabla = crearPanelTabla();
        add(panelTabla, BorderLayout.CENTER);
        
        // Panel inferior: Formulario
        JPanel panelFormulario = crearPanelFormulario();
        add(panelFormulario, BorderLayout.SOUTH);
        
        cargarDatos();
        
        this.addAncestorListener(new javax.swing.event.AncestorListener() {
            @Override
            public void ancestorAdded(javax.swing.event.AncestorEvent event) {
                cargarCategorias(); 
            }
            @Override
            public void ancestorRemoved(javax.swing.event.AncestorEvent event) {}
            @Override
            public void ancestorMoved(javax.swing.event.AncestorEvent event) {}
        });
    }
    
    
    private JPanel crearPanelTabla() {
        JPanel panel = new JPanel(new BorderLayout());
        
        // Crear tabla
        modeloTabla = new DefaultTableModel(
            new String[]{"ID", "Nombre", "Precio", "Cantidad", "Categoría"}, 0
        );
        tabla = new JTable(modeloTabla);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Listener para seleccionar fila
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() != -1) {
                int id = (int) modeloTabla.getValueAt(tabla.getSelectedRow(), 0);
                productoSeleccionado = servicio.getProductoDAO().getProducto(id);
            }
        });
        
        JScrollPane scroll = new JScrollPane(tabla);
        panel.add(scroll, BorderLayout.CENTER);
        
        // Panel de botones
        JPanel panelBotones = new JPanel();
        btnNuevo = new JButton("Nuevo");
        btnEditar = new JButton("Editar");
        btnEliminar = new JButton("Eliminar");
        
        btnNuevo.addActionListener(e -> cambiarEstado(Estado.ALTA));
        btnEditar.addActionListener(e -> cambiarEstado(Estado.MODIFICACION));
        btnEliminar.addActionListener(e -> eliminarProducto());
        
        panelBotones.add(btnNuevo);
        panelBotones.add(btnEditar);
        panelBotones.add(btnEliminar);
        
        panel.add(panelBotones, BorderLayout.NORTH);
        
        return panel;
    }
    
    private JPanel crearPanelFormulario() {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createTitledBorder("Formulario"));
        
        panel.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panel.add(txtNombre);
        
        panel.add(new JLabel("Precio:"));
        txtPrecio = new JTextField();
        panel.add(txtPrecio);
        
        panel.add(new JLabel("Cantidad:"));
        txtCantidad = new JTextField();
        panel.add(txtCantidad);
        
        panel.add(new JLabel("Categoría:"));
        cmbCategoria = new JComboBox<>();
        cargarCategorias();
        panel.add(cmbCategoria);
        
        JPanel panelBotones = new JPanel();
        btnGuardar = new JButton("Guardar");
        btnCancelar = new JButton("Cancelar");
        
        btnGuardar.addActionListener(e -> guardarProducto());
        btnCancelar.addActionListener(e -> cambiarEstado(Estado.CONSULTA));
        
        panelBotones.add(btnGuardar);
        panelBotones.add(btnCancelar);
        panel.add(panelBotones);
        
        return panel;
    }
    
    private void cambiarEstado(Estado nuevoEstado) {
        this.estado = nuevoEstado;
        
        switch (estado) {
            case CONSULTA:
                limpiarFormulario();
                habilitarFormulario(false);
                break;
            case ALTA:
                limpiarFormulario();
                habilitarFormulario(true);
                break;
            case MODIFICACION:
                if (productoSeleccionado != null) {
                    txtNombre.setText(productoSeleccionado.getNombre());
                    txtPrecio.setText(String.valueOf(productoSeleccionado.getPrecio()));
                    txtCantidad.setText(String.valueOf(productoSeleccionado.getCantidad()));
                    cmbCategoria.setSelectedItem(productoSeleccionado.getCategoria());
                    habilitarFormulario(true);
                }
                break;
        }
    }
    
    private void habilitarFormulario(boolean habilitar) {
        txtNombre.setEnabled(habilitar);
        txtPrecio.setEnabled(habilitar);
        txtCantidad.setEnabled(habilitar);
        cmbCategoria.setEnabled(habilitar);
        btnGuardar.setEnabled(habilitar);
        btnNuevo.setEnabled(!habilitar);
        btnEditar.setEnabled(!habilitar);
        btnEliminar.setEnabled(!habilitar);
    }
    
    private void limpiarFormulario() {
        txtNombre.setText("");
        txtPrecio.setText("");
        txtCantidad.setText("");
    }
    
    private void guardarProducto() {
        String nombre = txtNombre.getText().trim();
        String precioStr = txtPrecio.getText().trim();
        String cantidadStr = txtCantidad.getText().trim();
        Categoria categoria = (Categoria) cmbCategoria.getSelectedItem();
        
        if (nombre.isEmpty() || precioStr.isEmpty() || cantidadStr.isEmpty() || categoria == null) {
            JOptionPane.showMessageDialog(this, "Completa todos los campos");
            return;
        }
        
        try {
            double precio = Double.parseDouble(precioStr);
            int cantidad = Integer.parseInt(cantidadStr);
            
            if (estado == Estado.ALTA) {
                Producto nuevo = new Producto();
                nuevo.setNombre(nombre);
                nuevo.setPrecio(precio);
                nuevo.setCantidad(cantidad);
                nuevo.setCategoria(categoria);
                servicio.getProductoDAO().nuevoProducto(nuevo);
            } else if (estado == Estado.MODIFICACION) {
                productoSeleccionado.setNombre(nombre);
                productoSeleccionado.setPrecio(precio);
                productoSeleccionado.setCantidad(cantidad);
                productoSeleccionado.setCategoria(categoria);
                servicio.getProductoDAO().modificarProducto(productoSeleccionado);
            }
            
            cargarDatos();
            cambiarEstado(Estado.CONSULTA);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Precio y Cantidad deben ser números");
        }
    }
    
    private void eliminarProducto() {
        if (productoSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "Selecciona un producto");
            return;
        }
        
        int opcion = JOptionPane.showConfirmDialog(this, "¿Eliminar este producto?");
        if (opcion == JOptionPane.YES_OPTION) {
            servicio.getProductoDAO().eliminarProducto(productoSeleccionado);
            cargarDatos();
            cambiarEstado(Estado.CONSULTA);
        }
    }
    
    private void cargarCategorias() {
        cmbCategoria.removeAllItems();
        List<Categoria> categorias = servicio.getCategoriaDAO().getCategoria();
        for (Categoria c : categorias) {
            cmbCategoria.addItem(c);
        }
    }
    
    private void cargarDatos() {
        modeloTabla.setRowCount(0);
        List<Producto> productos = servicio.getProductoDAO().getProducto();
        for (Producto p : productos) {
            modeloTabla.addRow(new Object[]{
                p.getId(), 
                p.getNombre(), 
                p.getPrecio(), 
                p.getCantidad(),
                p.getCategoria().getNombre()
                    
            });
        }
    }
}