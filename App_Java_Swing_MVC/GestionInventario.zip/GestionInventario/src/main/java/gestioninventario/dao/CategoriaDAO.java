/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package gestioninventario.dao;

import gestioninventario.modelo.Categoria;
import gestioninventario.modelo.Producto;
import java.util.List;

/**
 *
 * @author fabia
 */
public interface CategoriaDAO {
    Categoria getCategoria(Integer id);
    Categoria nuevaCategoria (Categoria nueva);
    List <Categoria> getCategoria();
    void agregarProducto (Categoria c, Producto p);
    void eliminarCategoria(Categoria eliminar);
    void actualizarCategoria(Categoria actualizar);
    
    
}
