/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioninventario;
import gestioninventario.vista.InventarioPrincipalVista;
import javax.swing.SwingUtilities;

/**
 *
 * @author fabia
 */
public class GestionInventario {

    public static void main(String[] args) {
       
    SwingUtilities.invokeLater(() -> new InventarioPrincipalVista());
}
}